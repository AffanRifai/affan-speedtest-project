<?php
// Kita tidak perlu memproses file, cukup terima data POST untuk simulasi upload
http_response_code(200);
echo "upload received";
?>
