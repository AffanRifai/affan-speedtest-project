<?php
header("Content-Type: text/plain");
echo "pong"; // cukup kirim teks sederhana untuk hitung waktu respons
?>
